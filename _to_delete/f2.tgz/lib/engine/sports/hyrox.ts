/**
 * HYROX as `SPORTS.hyrox` (P0). Values are IMPORTED from the existing engine
 * constants wherever possible, so this config cannot drift from live behavior —
 * it is an aggregation of the current source of truth, not a hand-copied
 * duplicate. Fields the config layer will own later but the engine still reads
 * inline today (session counts, station catalog, zone targets) are wired here so
 * the subsequent consumer-rewire is a mechanical swap, gated by the oracle.
 */
import {
  ZONE_DEFINITIONS,
  RUN_GUIDANCE,
  LIFT_GUIDANCE,
  HYBRID_GUIDANCE,
  TAPER_GUIDANCE,
  HYBRID_LIBRARY,
  PHASE_CHARACTER,
} from "@/lib/ai/philosophy";
import { STATIONS, RACE_STATION_ORDER, HYROX_CATALOG } from "../stations";
import { RUN_COUNT, HYBRID_COUNT } from "../slots";
import { PHASE_ZONE_TARGETS, STARTING_MILEAGE, AVG_MIN_PER_MILE } from "../volume";
import type { PhaseName } from "../types";
import type { SportConfig } from "./types";

const LIFT_COUNT: Record<PhaseName, number> = { base: 3, build: 3, peak: 3, taper: 2 };

export const hyrox: SportConfig = {
  id: "hyrox",
  family: "station_hybrid",
  displayName: "HYROX",
  programType: "race_peaking",

  modalities: ["run", "lift", "hybrid", "rest", "race"],
  sessionCounts: {
    run: RUN_COUNT, // [beg, int, adv] per phase
    hybrid: HYBRID_COUNT,
    lift: LIFT_COUNT,
  },

  stations: STATIONS,
  raceStationOrder: RACE_STATION_ORDER,
  stationCatalog: HYROX_CATALOG,
  interStationRunMeters: 1000,
  totalRaceRunMeters: 8000,

  phaseZoneTargets: PHASE_ZONE_TARGETS,

  // Research Section 6.3 three-zone (Z1/Z2/Z3) intensity targets by weekly-hours
  // budget. hard (Z3) rises as hours fall — intensity substitutes for missing
  // volume — which the flat band shift could not express.
  bandZone3Z: {
    h0_5: { easy: 55, gray: 25, hard: 20 },
    h5_10: { easy: 70, gray: 15, hard: 15 },
    h10_20: { easy: 80, gray: 8, hard: 12 },
    h20_30: { easy: 85, gray: 4, hard: 11 },
    h30_40: { easy: 88, gray: 3, hard: 9 },
  },

  // Research Section 6.3 strength dose: 1 heavy (5h) -> heavy+power (10-20h) ->
  // +a third quality lift at high volume. Replaces the 3-day upper/lower/full split.
  // [min,max] lifts/week by budget, scaled within range by lifting experience.
  // 0-5h:1 | 6-10h:2 | 11-20h:2-3 | 21-30h:3-4 | 31-40h:3-4. Split caps heavy at 2/wk.
  bandLiftCounts: { h0_5: [1, 1], h5_10: [2, 2], h10_20: [2, 3], h20_30: [3, 4], h30_40: [3, 4] },

  // Needs domains for the station-hybrid family. The authoritative scoring
  // functions + full multi-metric anchors live in lib/engine/needs.ts; these
  // entries are the registry contract the rewire will point that logic at.
  needsDomains: [
    {
      key: "run_engine",
      label: "running endurance",
      scorerId: "run_engine",
      anchors: { male: [360, 720], female: [396, 792] }, // 10k pace sec/mi [best,worst]
      weight: 1,
    },
    {
      key: "erg_engine",
      label: "erg / non-running cardio",
      scorerId: "erg_engine",
      anchors: { male: [400, 560], female: [460, 644] }, // 2k row sec [best,worst]
      weight: 1,
    },
    {
      key: "strength",
      label: "maximal strength",
      scorerId: "strength",
      anchors: { male: [1.0, 2.25], female: [0.8, 1.8] }, // rel squat 1RM [worst,best]
      weight: 1,
    },
  ],

  experienceAxes: [
    {
      key: "running",
      label: "Running",
      needsWeight: 1,
      bands: [
        { level: "beginner", criterion: "under 15 miles/week sustained over the last 6 months" },
        { level: "intermediate", criterion: "15–30 miles/week sustained over the last 6 months" },
        { level: "advanced", criterion: "over 30 miles/week sustained over the last 6 months" },
      ],
    },
    {
      key: "hybrid",
      label: "Hybrid (HIIT)",
      needsWeight: 1,
      bands: [
        { level: "beginner", criterion: "≤1 hybrid HIIT workout/week over the last 6 months" },
        { level: "intermediate", criterion: "2 hybrid HIIT workouts/week over the last 6 months" },
        { level: "advanced", criterion: "≥3 hybrid HIIT workouts/week over the last 6 months" },
      ],
    },
    {
      key: "lifting",
      label: "Lifting",
      needsWeight: 1,
      bands: [
        { level: "beginner", criterion: "lifting consistently for under 3 years" },
        { level: "intermediate", criterion: "lifting consistently for 3–5 years" },
        { level: "advanced", criterion: "lifting consistently for over 5 years" },
      ],
    },
  ],

  volume: {
    kind: "single_currency",
    startMileageByExp: STARTING_MILEAGE,
    avgMinPerMile: AVG_MIN_PER_MILE,
  },

  philosophy: {
    coach: "expert HYROX coach",
    guidance: [ZONE_DEFINITIONS, RUN_GUIDANCE, LIFT_GUIDANCE, HYBRID_GUIDANCE, TAPER_GUIDANCE],
    stationLibrary: HYBRID_LIBRARY,
    phaseCharacter: PHASE_CHARACTER,
  },
};
