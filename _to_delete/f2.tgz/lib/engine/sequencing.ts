/**
 * Concurrent-training sequencing guards (Review #8) — split out of slots.ts
 * (roadmap #2.6).
 *
 * Endurance and strength adaptations interfere (AMPK vs mTOR), and heavy leg
 * work leaves residual fatigue that compromises a quality run the next day. So
 * we keep heavy-leg lifts (lower / full body) off the day BEFORE a key run
 * (long / interval / threshold / tempo). Best-effort + count-preserving: it only
 * relocates onto unprotected days and never onto (or the day before) another key
 * run, and only pushes a "light" session back to the vacated day.
 */

import type { DaySlot, RunType, SessionSlot, SlotPredicate, TrainingDayName } from "./types";

const KEY_RUN_TYPES: ReadonlySet<RunType> = new Set(["long", "interval", "threshold", "tempo"]);
export const isKeyRun: SlotPredicate = (s) => s.kind === "run" && KEY_RUN_TYPES.has(s.runType);
export const isHardLegLift: SlotPredicate = (s) =>
  s.kind === "lift" && (s.liftType === "lower" || s.liftType === "full" || s.liftType === "power");

/** A session light enough to sit the day before a key run (no leg fatigue). */
function isLightSlot(s: SessionSlot): boolean {
  if (s.kind === "rest") return true;
  if (s.kind === "run") return !isKeyRun(s);
  if (s.kind === "lift") return s.liftType === "upper";
  return false; // hybrid / race are not "light"
}

function dayHas(day: DaySlot, pred: SlotPredicate): boolean {
  return day.sessions.some(pred);
}

/** Index of a movable "light" session on a day, or -1. */
function lightIndex(day: DaySlot): number {
  return day.sessions.findIndex(isLightSlot);
}

/**
 * Pick a day to relocate a heavy-leg lift to: unprotected, not a key-run day,
 * not the day before a key run, and able to give back a light session (or empty).
 * Empty days are strongly preferred. Returns the day index, or -1.
 */
function pickSequencingTarget(
  days: DaySlot[],
  keyRunIdx: number,
  protectedDays: Set<TrainingDayName>,
): number {
  const beforeKeyRun = (t: number) => t + 1 < days.length && dayHas(days[t + 1]!, isKeyRun); // safe: t + 1 < days.length
  let best = -1;
  let bestScore = -Infinity;
  for (let t = 0; t < days.length; t++) {
    if (t === keyRunIdx || t === keyRunIdx - 1) continue;
    const day = days[t]!; // safe: t < days.length
    if (protectedDays.has(day.day)) continue;
    if (dayHas(day, isKeyRun)) continue;
    if (beforeKeyRun(t)) continue;
    const empty = day.sessions.length === 0;
    if (!empty && lightIndex(day) === -1) continue; // nothing safe to swap back
    const load = day.sessions.filter((x) => x.kind !== "rest").length;
    const score = (empty ? 100 : 0) - load;
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  }
  return best;
}

/** Relocate heavy-leg lifts that sit the day before a key run. */
export function applySequencingGuards(days: DaySlot[], protectedDays: Set<TrainingDayName>): void {
  for (let i = 1; i < days.length; i++) {
    const day = days[i]!; // safe: i < days.length
    if (!dayHas(day, isKeyRun)) continue;
    const prev = days[i - 1]!; // safe: i >= 1
    if (protectedDays.has(prev.day)) continue;
    const j = prev.sessions.findIndex(isHardLegLift);
    if (j === -1) continue;
    const target = pickSequencingTarget(days, i, protectedDays);
    if (target === -1) continue;

    const lift = prev.sessions.splice(j, 1)[0]!; // safe: j is a valid index (!== -1)
    const tgt = days[target]!; // safe: pickSequencingTarget returns a valid index or -1
    if (tgt.sessions.length === 0) {
      tgt.sessions.push(lift);
    } else {
      const di = lightIndex(tgt); // guaranteed ≥ 0 by pickSequencingTarget
      const back = tgt.sessions.splice(di, 1)[0]!; // safe: di ≥ 0 (a light session exists)
      prev.sessions.push(back);
      tgt.sessions.push(lift);
    }
  }
}

// --- Research-aligned scheduling guards (engine-vs-research batch 3) ----------
//
// Two rules from the engine-vs-research gap analysis, applied ONLY for
// research-lift programs (gated at the call site on counts.researchLifts, so the
// golden oracle — which has no weeklyHours — is untouched):
//   1. No two lifts on the same day. A second weight session is relocated to a
//      lift-free day (the research separates concurrent strength sessions).
//   2. Every hard-leg lift day (lower / full / power) is paired with easy Z1–Z2
//      cardio on the SAME day. An easy run is pulled onto it from another day.
// Both are best-effort and session-count-preserving: they only relocate existing
// sessions onto unprotected days and never create or drop a session.

/** Any endurance session that counts as "cardio" for same-day leg-lift pairing. */
function isCardio(s: SessionSlot): boolean {
  return (
    s.kind === "run" ||
    s.kind === "hybrid" ||
    s.kind === "bike" ||
    s.kind === "swim" ||
    s.kind === "brick"
  );
}

/** A movable easy Z1–Z2 run (never the long run or any quality run). */
const isEasyRun: SlotPredicate = (s) => s.kind === "run" && s.runType === "easy";

/** True if placing a hard-leg lift on day `t` would sit it on — or the day
 *  before — a key run, breaking the applySequencingGuards invariant. */
function conflictsWithKeyRun(days: DaySlot[], t: number): boolean {
  if (dayHas(days[t]!, isKeyRun)) return true; // safe: t is a valid index in the caller loop
  return t + 1 < days.length && dayHas(days[t + 1]!, isKeyRun); // safe: t + 1 < days.length
}

/**
 * Pick a lift-free day to relocate an extra lift onto: unprotected, holding no
 * existing lift, and — for hard-leg lifts — clear of key-run fatigue. A day that
 * already has easy cardio is ideal (the moved leg lift auto-pairs); otherwise an
 * empty/light day is preferred. Returns the day index, or -1.
 */
function pickNoLiftDay(
  days: DaySlot[],
  fromIdx: number,
  lift: SessionSlot,
  protectedDays: Set<TrainingDayName>,
): number {
  const legLift = isHardLegLift(lift);
  let best = -1;
  let bestScore = -Infinity;
  for (let t = 0; t < days.length; t++) {
    if (t === fromIdx) continue;
    const day = days[t]!; // safe: t < days.length
    if (protectedDays.has(day.day)) continue;
    if (dayHas(day, (s) => s.kind === "lift")) continue; // HARD: never two lifts on a day
    const load = day.sessions.filter((x) => x.kind !== "rest").length;
    const pairs = legLift && dayHas(day, isCardio) ? 1 : 0; // leg lift onto easy cardio = ideal
    // Key-run adjacency is a strong PREFERENCE, not a veto: the no-two-lifts rule
    // must always win, so we penalize a conflicting day rather than skip it (in a
    // dense peak week nearly every day is key-run-adjacent — skipping stranded the
    // extra lift and left two on one day).
    const conflict = legLift && conflictsWithKeyRun(days, t) ? 1 : 0;
    const score = pairs * 200 + (load === 0 ? 50 : 0) - load - conflict * 500;
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  }
  return best;
}

/** Rule 1: no two lifts on the same day (relocate the extras, keep the first). */
export function separateLifts(days: DaySlot[], protectedDays: Set<TrainingDayName>): void {
  const liftIdxs = (day: DaySlot): number[] =>
    day.sessions.map((s, k) => (s.kind === "lift" ? k : -1)).filter((k) => k >= 0);
  for (let i = 0; i < days.length; i++) {
    const day = days[i]!; // safe: i < days.length
    let idxs = liftIdxs(day);
    while (idxs.length > 1) {
      const moveIdx = idxs[idxs.length - 1]!; // relocate the last lift on the day
      const lift = day.sessions[moveIdx]!; // safe: moveIdx is a valid session index
      const target = pickNoLiftDay(days, i, lift, protectedDays);
      if (target === -1) break; // nowhere safe — leave it (best-effort)
      day.sessions.splice(moveIdx, 1);
      days[target]!.sessions.push(lift); // safe: pickNoLiftDay returns a valid index or -1
      idxs = liftIdxs(day);
    }
  }
}

/**
 * A source day to pull an easy run off, without unpairing another leg lift:
 * unprotected, holding an easy run, and — if it also has a hard-leg lift — with
 * a spare cardio session left behind. Prefers days with no leg lift and the most
 * cardio. Returns the day index, or -1.
 */
function pickEasyRunSource(
  days: DaySlot[],
  destIdx: number,
  protectedDays: Set<TrainingDayName>,
): number {
  let best = -1;
  let bestScore = -Infinity;
  for (let t = 0; t < days.length; t++) {
    if (t === destIdx) continue;
    const day = days[t]!; // safe: t < days.length
    if (protectedDays.has(day.day)) continue;
    if (!dayHas(day, isEasyRun)) continue;
    const cardioCount = day.sessions.filter(isCardio).length;
    const legHere = dayHas(day, isHardLegLift);
    if (legHere && cardioCount <= 1) continue; // don't strip the only cardio off a leg-lift day
    const score = (legHere ? 0 : 100) + cardioCount;
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  }
  return best;
}

/** Rule 2: pair every hard-leg-lift day with easy Z1–Z2 cardio on the same day. */
export function pairLegLiftWithCardio(days: DaySlot[], protectedDays: Set<TrainingDayName>): void {
  for (let i = 0; i < days.length; i++) {
    const day = days[i]!; // safe: i < days.length
    if (!dayHas(day, isHardLegLift)) continue;
    if (dayHas(day, isCardio)) continue; // already paired
    const src = pickEasyRunSource(days, i, protectedDays);
    if (src === -1) continue; // no movable easy run — leave it (best-effort)
    const j = days[src]!.sessions.findIndex(isEasyRun);
    if (j === -1) continue; // defensive: pickEasyRunSource guarantees one exists
    const run = days[src]!.sessions.splice(j, 1)[0]!; // safe: j !== -1
    day.sessions.push(run);
  }
}


// --- Daily-load guards (per-day session limits) ------------------------------
//
// Two structural rules layered on top of the batch-3 guards, applied only for
// research-lift programs (gated at the call site on counts.researchLifts, so the
// golden oracle is untouched):
//   #2  A day may hold a SECOND run only once every (unprotected) training day
//       already has a run — runs spread across days before they double up.
//   #1  No more than 2 workouts on any single day — a 3rd+ session is relocated
//       to a lighter day (respecting rest-day preferences and the no-two-lifts
//       rule). Both are best-effort and session-count-preserving.

const isRun: SlotPredicate = (s) => s.kind === "run";
const isLift: SlotPredicate = (s) => s.kind === "lift";
/** The weekly long run is pinned to its (preferred or weekend-default) day by
 *  assignDays; these load guards must never relocate it. Protected-day checks
 *  only guard a DESTINATION, so the long run needs an explicit exemption here. */
const isLongRunSlot: SlotPredicate = (s) => s.kind === "run" && (s.isLong === true || s.runType === "long");

/** Non-rest workouts on a day (rest slots aren't added until after the guards). */
function workoutCount(day: DaySlot): number {
  return day.sessions.filter((s) => s.kind !== "rest").length;
}
function runCount(day: DaySlot): number {
  return day.sessions.filter(isRun).length;
}

/** Lower = relocate this run first (keep the long run on its day). */
function runMovability(s: SessionSlot): number {
  if (s.kind !== "run") return 99;
  if (s.isLong || s.runType === "long") return 2;
  if (s.runType === "easy") return 0;
  return 1;
}

/** Lower = relocate this session first off an overloaded day. */
function sessionMovability(s: SessionSlot): number {
  if (s.kind === "run") return s.isLong || s.runType === "long" ? 6 : s.runType === "easy" ? 1 : 3;
  if (s.kind === "hybrid") return 4;
  if (s.kind === "lift") return 5;
  return 8; // race / swim / bike / brick — pinned (not produced for research-lift sports)
}

/**
 * Rule #2: runs spread across days before doubling. While some day stacks ≥2
 * runs and an unprotected day has none (with room for another session), move the
 * most-movable run onto the emptiest run-less day.
 */
export function spreadRuns(days: DaySlot[], protectedDays: Set<TrainingDayName>): void {
  for (let guard = 0; guard < days.length * 4; guard++) {
    const srcIdx = days.findIndex((d) => runCount(d) >= 2);
    if (srcIdx === -1) break;
    let best = -1;
    let bestLoad = Infinity;
    for (let t = 0; t < days.length; t++) {
      const d = days[t]!; // safe: t < days.length
      if (protectedDays.has(d.day)) continue;
      if (runCount(d) > 0) continue;
      const load = workoutCount(d);
      if (load >= 2) continue; // adding a run would break the 2-per-day cap
      if (load < bestLoad) {
        bestLoad = load;
        best = t;
      }
    }
    if (best === -1) break; // every day already has a run (or no room) — doubling allowed
    const src = days[srcIdx]!; // safe: findIndex returned a valid index
    const movable = src.sessions
      .map((sl, i) => ({ sl, i }))
      .filter((x) => x.sl.kind === "run" && !isLongRunSlot(x.sl)) // never move the long run
      .sort((a, b) => runMovability(a.sl) - runMovability(b.sl));
    if (movable.length === 0) break; // only the long run here — leave it put
    const moveIdx = movable[0]!.i; // safe: srcIdx has ≥2 runs
    const run = src.sessions.splice(moveIdx, 1)[0]!; // safe: moveIdx is a valid index
    days[best]!.sessions.push(run); // safe: best is a valid index
  }
}

/** A lighter, unprotected day that can accept `sess` under the 2-per-day cap. */
function pickCapTarget(
  days: DaySlot[],
  fromIdx: number,
  sess: SessionSlot,
  protectedDays: Set<TrainingDayName>,
  max: number,
): number {
  const wantRun = sess.kind === "run";
  const wantLift = sess.kind === "lift";
  let best = -1;
  let bestScore = -Infinity;
  for (let t = 0; t < days.length; t++) {
    if (t === fromIdx) continue;
    const d = days[t]!; // safe: t < days.length
    if (protectedDays.has(d.day)) continue;
    const load = workoutCount(d);
    if (load >= max) continue;
    if (wantLift && dayHas(d, isLift)) continue; // never two lifts on a day
    const runless = runCount(d) === 0;
    const score = (load === 0 ? 100 : 0) + (wantRun && runless ? 50 : 0) - load; // prefer empty, then runless for runs
    if (score > bestScore) {
      bestScore = score;
      best = t;
    }
  }
  return best;
}

/**
 * Rule #1: no more than `max` (default 2) workouts on any day. Relocate the
 * most-movable excess session to a lighter day; keep lifts and the long run put.
 */
export function capSessionsPerDay(days: DaySlot[], protectedDays: Set<TrainingDayName>, max = 2): void {
  for (let guard = 0; guard < days.length * 6; guard++) {
    const srcIdx = days.findIndex((d) => workoutCount(d) > max);
    if (srcIdx === -1) break;
    const src = days[srcIdx]!; // safe: findIndex returned a valid index
    const order = src.sessions
      .map((sl, i) => ({ sl, i }))
      .filter((x) => x.sl.kind !== "rest" && !isLongRunSlot(x.sl)) // long run is pinned
      .sort((a, b) => sessionMovability(a.sl) - sessionMovability(b.sl));
    let moved = false;
    for (const cand of order) {
      const t = pickCapTarget(days, srcIdx, cand.sl, protectedDays, max);
      if (t === -1) continue;
      const sess = src.sessions.splice(cand.i, 1)[0]!; // safe: cand.i is a valid index
      days[t]!.sessions.push(sess); // safe: pickCapTarget returns a valid index or -1
      moved = true;
      break;
    }
    if (!moved) break; // nowhere safe to move anything — best-effort
  }
}
